from flask import Flask, render_template, request, redirect, session, flash, url_for
from db_config import get_connection
from decorators import role_required
from adminuser import register_admin_routes
from admindriver import register_admin_driver_routes
from adminbookings import register_admin_booking_routes
from adminpricing import register_admin_pricing_routes
from driverfull import register_driver_routes
from userfull import register_user_routes


app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Register route modules
register_admin_routes(app)
register_admin_driver_routes(app)
register_admin_booking_routes(app)
register_admin_pricing_routes(app)
register_driver_routes(app)
register_user_routes(app)

# ----------------------------
# Login Route
# ----------------------------
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        userid = request.form['userid'].strip()
        password = request.form['password'].strip()
        role = request.form['role'].strip().lower()

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        user = None

        if role == 'admin':
            cursor.execute("SELECT * FROM admin_users WHERE username=%s AND password=%s", (userid, password))
            user = cursor.fetchone()

        elif role == 'driver':
            cursor.execute("SELECT * FROM drivers WHERE user_id=%s AND password=%s", (userid, password))
            driver = cursor.fetchone()

            if not driver:
                flash("Invalid driver credentials.", "danger")
                return redirect('/')

            if driver['approved'] != 1:
                flash("⛔ Your account is not approved yet. Please wait for admin approval.", "warning")
                return redirect('/')

            user = driver  # ✅ assign driver to user

        elif role == 'user':
            cursor.execute("SELECT * FROM users WHERE user_id=%s AND password=%s", (userid, password))
            user = cursor.fetchone()

        else:
            flash("Invalid role selected.", "danger")
            return redirect('/')

        cursor.close()
        conn.close()

        if user:
            if role == 'admin':
                session['user_id'] = user['username']
            elif role == 'user':
                session['user_id'] = user['id']  # INT used for FK
                session['user_name'] = user['name']
            elif role == 'driver':
                session['user_id'] = user['user_id']  # e.g., 'driver1'
                session['driver_name'] = user['name']

            session['role'] = role
            flash("Login successful!", "success")
            return redirect('/dashboard')

        else:
            flash("Invalid credentials. Please try again.", "danger")
            return redirect('/')

    return render_template('login.html')




# ----------------------------
# Role-Based Dashboard
# ----------------------------
@app.route('/dashboard')
def dashboard():
    print("=== SESSION DEBUG ===")
    print("session.get('user_id') =", session.get('user_id'))
    print("session.get('role') =", session.get('role'))

    if not session.get('user_id') or not session.get('role'):
        flash("Unauthorized access. Please login.", "danger")
        return redirect('/')

    return render_template('dashboard.html', role=session['role'], userid=session['user_id'])




# ----------------------------
# Logout
# ----------------------------
@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect('/')

# ----------------------------
# Run App
# ----------------------------
if __name__ == '__main__':
    app.run(debug=True)
